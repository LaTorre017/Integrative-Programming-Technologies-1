<?php

$grade = 95;

switch ($grade) {

case ($grade >= 98) : 
echo "Excellent"; 
break;

case  ($grade >= 95) :
echo " Very Good";
break;

case ($grade >= 90) : 
echo " Good ";
break;

case ($grade >= 85) : 
echo " Fairly Good";
break;

case ($grade >= 80) :
echo " Average ";
break;

case ($grade >= 75) :
echo " Below Average";
break;

case ($grade >= 70) :
echo " Poor";
break;

case ($grade >= 60) :
echo " Very Poor ";
break;

default :
echo " Invalid Grade";

}

?>