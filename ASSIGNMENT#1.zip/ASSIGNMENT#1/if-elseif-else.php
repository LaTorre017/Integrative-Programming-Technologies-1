<?php

$grade = 66 ;

If ($grade >= 75) {
echo " PASSED " ; }

else if ($grade >= 60) { 
echo "FAILED";}

else{
echo " INCOMPLETE";}

?>